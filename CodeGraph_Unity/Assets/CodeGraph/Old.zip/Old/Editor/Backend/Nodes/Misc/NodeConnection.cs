using CodeGraph.Old.Backend.Nodes.Abstracts;

namespace CodeGraph.Old.Backend.Nodes.Misc {
    public class NodeConnection {
        public OutputNode From;
        public InputNode To;

        public static NodeConnection Create(OutputNode from, InputNode to) {
            return new NodeConnection {From = from, To = to};
        }
    }
}