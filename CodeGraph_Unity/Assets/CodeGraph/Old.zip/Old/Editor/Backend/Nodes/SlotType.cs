namespace CodeGraph.Old.Backend.Nodes {
    public enum SlotType {
        Input,
        Output
    }
}