using System.Collections.Generic;
using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.OutputNodes;

namespace CodeGraph.Old.Backend.Nodes.ValueNodes {
    public class FloatValueNode : ValueNode {
        public FloatValueNode() {
            NodeValueType = typeof(float);
            Outputs = new List<OutputNode> {new FloatOutputNode(this)};
        }
        public override string GetCode(int callStackLevel) {
            return $"{NodeValue}f";
        }

        public override void SetValue(object value) {
            if (value.GetType() == NodeValueType) NodeValue = (float)value;
        }
    }
}