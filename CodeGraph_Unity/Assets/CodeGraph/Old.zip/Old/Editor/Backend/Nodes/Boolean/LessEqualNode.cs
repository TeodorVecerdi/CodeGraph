using System.Collections.Generic;
using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.InputNodes;
using CodeGraph.Old.Backend.Nodes.OutputNodes;

namespace CodeGraph.Old.Backend.Nodes.Boolean {
    public class LessEqualNode : Node {
        public LessEqualNode() {
            Inputs = new List<InputNode> {new AnyInputNode(this), new AnyInputNode(this)};
            Outputs = new List<OutputNode> {new BooleanOutputNode(this)};
        }
        public override string GetCode(int callStackLevel) {
            return $"{Inputs[0].OutputLocationReference.ParentNodeReference.GetCode(callStackLevel+1)} <= {Inputs[1].OutputLocationReference.ParentNodeReference.GetCode(callStackLevel+1)}";
        }
    }
}