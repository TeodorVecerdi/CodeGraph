using System.Collections.Generic;
using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.OutputNodes;

namespace CodeGraph.Old.Backend.Nodes.ValueNodes {
    public class IntegerValueNode : ValueNode {
        public IntegerValueNode() {
            NodeValueType = typeof(int);
            Outputs = new List<OutputNode> {new IntegerOutputNode(this)};
        }
        public override string GetCode(int callStackLevel) {
            return $"{NodeValue}";
        }

        public override void SetValue(object value) {
            if (value.GetType() == NodeValueType) NodeValue = (int)value;
        }
    }
}