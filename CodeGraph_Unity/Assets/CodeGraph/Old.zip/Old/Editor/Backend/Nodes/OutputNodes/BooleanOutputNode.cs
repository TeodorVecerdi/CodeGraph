    using CodeGraph.Old.Backend.Nodes.Abstracts;

    namespace CodeGraph.Old.Backend.Nodes.OutputNodes {
        public class BooleanOutputNode : OutputNode {
            public BooleanOutputNode(Node parent) {
                OutputType = typeof(bool);
                ParentNodeReference = parent;
            }

            public override bool CanAcceptNode(InputNode inputNode) {
                return inputNode.InputType == OutputType;
            }
        }
    }