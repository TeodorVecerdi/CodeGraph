using System;

namespace CodeGraph.Old.Backend.Nodes.Abstracts {
    public abstract class InputNode {
        public Type InputType = typeof(object);
        public OutputNode OutputLocationReference;
        public Node ParentNodeReference;
        public abstract bool CanAcceptNode(OutputNode outputNode);
    }
}