using CodeGraph.Old.Backend.Nodes.Abstracts;

    namespace CodeGraph.Old.Backend.Nodes.InputNodes {
        public class AnyInputNode : InputNode {
            public AnyInputNode(Node parent) {
                ParentNodeReference = parent;
            }

            public override bool CanAcceptNode(OutputNode outputNode) {
                return true;
            }
        }
    }