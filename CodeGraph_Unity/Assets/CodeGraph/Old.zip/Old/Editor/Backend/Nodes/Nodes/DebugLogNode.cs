using System.Collections.Generic;
using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.InputNodes;
using CodeGraph.Old.Backend.Nodes.OutputNodes;

namespace CodeGraph.Old.Backend.Nodes.Nodes {
    public class DebugLogNode : Node {
        public DebugLogNode() {
            Inputs = new List<InputNode> {new AnyInputNode(this)};
            Outputs = new List<OutputNode>{new AnyOutputNode(this)};
        }

        public override string GetCode(int callStackLevel) {
            return $"UnityEngine.Debug.Log({Inputs[0].OutputLocationReference.ParentNodeReference.GetCode(callStackLevel+1)})";
        }
    }
}