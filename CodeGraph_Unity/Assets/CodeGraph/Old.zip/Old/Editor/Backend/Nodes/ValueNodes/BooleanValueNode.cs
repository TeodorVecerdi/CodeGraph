
using System.Collections.Generic;
using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.OutputNodes;

namespace CodeGraph.Old.Backend.Nodes.ValueNodes {
    public class BooleanValueNode : ValueNode{
        public BooleanValueNode() {
            NodeValueType = typeof(bool);
            Outputs = new List<OutputNode> {new BooleanOutputNode(this)};
        }
        public override string GetCode(int callStackLevel) {
            return (bool)NodeValue ? "true" : "false";
        }

        public override void SetValue(object value) {
            if (value.GetType() == NodeValueType) NodeValue = (bool)value;
        }
    }
}