using CodeGraph.Old.Backend.Nodes.Abstracts;

namespace CodeGraph.Old.Backend.Nodes.OutputNodes {
    public class AnyOutputNode : OutputNode {
        public AnyOutputNode(Node parent) {
            ParentNodeReference = parent;
        }

        public override bool CanAcceptNode(InputNode inputNode) {
            return true;
        }
    }
}