using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.Nodes;

namespace CodeGraph.Old.Backend.Nodes.InputNodes {
    public class CodeBranchInputNode : InputNode {
        public CodeBranchInputNode(Node parent) {
            InputType = typeof(CodeBranchNode);
            ParentNodeReference = parent;
        }
        public override bool CanAcceptNode(OutputNode outputNode) {
            return true;
        }
    }
}