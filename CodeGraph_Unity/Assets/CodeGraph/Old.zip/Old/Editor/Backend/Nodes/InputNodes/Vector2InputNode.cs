    using CodeGraph.Old.Backend.Nodes.Abstracts;

    namespace CodeGraph.Old.Backend.Nodes.InputNodes {
        public class Vector2InputNode : InputNode{
            public Vector2InputNode(Node parent) {
                InputType = typeof(UnityEngine.Vector2);
                ParentNodeReference = parent;
            }
        
            public override bool CanAcceptNode(OutputNode outputNode) {
                return outputNode.OutputType == InputType;
            }
        }
    }