using CodeGraph.Old.Backend.Nodes.Abstracts;
using CodeGraph.Old.Backend.Nodes.Nodes;

namespace CodeGraph.Old.Backend.Nodes.OutputNodes {
    public class CodeBranchOutputNode : OutputNode {
        public CodeBranchOutputNode(Node parent) {
            OutputType = typeof(CodeBranchNode);
            ParentNodeReference = parent;
        }
        public override bool CanAcceptNode(InputNode inputNode) {
            return inputNode.InputType == OutputType;
        }
    }
}