    using CodeGraph.Old.Backend.Nodes.Abstracts;

    namespace CodeGraph.Old.Backend.Nodes.InputNodes {
        public class BooleanInputNode : InputNode {

            public BooleanInputNode(Node parent) {
                InputType = typeof(bool);
                ParentNodeReference = parent;
            }

            public override bool CanAcceptNode(OutputNode outputNode) {
                return outputNode.OutputType == InputType;
            }
        }
    }