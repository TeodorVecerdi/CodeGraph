using System;
using System.Collections.Generic;

namespace CodeGraph.Old.Backend.Nodes.Abstracts {
    public abstract class OutputNode {
        public Type OutputType = typeof(object);
        public List<InputNode> InputLocationReferences = new List<InputNode>();
        public Node ParentNodeReference;
        public abstract bool CanAcceptNode(InputNode inputNode);
    }
}