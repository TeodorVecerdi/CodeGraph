namespace CodeGraph.Old.Backend.Interfaces {
    internal interface IGeneratesCode {
        string GetCode();
    }
}