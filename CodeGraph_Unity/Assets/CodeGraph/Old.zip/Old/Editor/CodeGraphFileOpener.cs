using CodeGraph.Old.Backend;
using CodeGraph.Old.GraphEditor;
using UnityEditor;

namespace CodeGraph.Old {
    public static class CodeGraphFileOpener {
        
        [UnityEditor.Callbacks.OnOpenAsset(1)]
        public static bool OnOpenAsset(int instanceID, int line) {
            string assetPath = AssetDatabase.GetAssetPath(instanceID);
            var graph = GraphFileSaveManager.LoadGraphFile(assetPath);
            if (graph != null) {
                var window = EditorWindow.GetWindow<GraphEditorWindow>();
                window.SetGraph(graph);
                window.Init();
                return true;
            }
            return false; //let unity open it.
        }
    }
}